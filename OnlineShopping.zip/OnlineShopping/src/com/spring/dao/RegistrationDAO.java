package com.spring.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.dto.UserDTO;

@Repository
public class RegistrationDAO {

	@Autowired
	private SessionFactory factory;

	public Integer saveUSer(UserDTO userDTO) {
		Transaction transaction = null;
		Integer numberOfUserRegistered = null;
		try (Session session = factory.openSession()) {
			transaction = session.beginTransaction();
			numberOfUserRegistered = (Integer) session.save(userDTO);
			transaction.commit();
		session.close();
		} catch (HibernateException e) {
			e.printStackTrace();
			//transaction.rollback();
		}
		
		return numberOfUserRegistered;
	}

}
