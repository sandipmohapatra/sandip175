package com.javatpoint.rest;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;
@Path("/product")
public class ProductService{
 	@POST
 	@Path("/result")
	public Response addUser(
		@FormParam("t1") int t1,
		@FormParam("t2") int t2,
		@FormParam("t3") String t3)
 	{
 		if(t3.equals("add"))
 		{
 		return Response.status(200)
			.entity(" Result is: "+(t1+t2))
			.build();
 	}
 		if(t3.equals("sub"))
 		{
 		return Response.status(200)
			.entity(" Result is: "+(t1 - t2))
			.build();
 	}
		return null;
}
}





